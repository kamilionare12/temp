/* Very Simple Contact Form anchor */

if(document.getElementById("raviol-anchor")) {
	document.getElementById("raviol-anchor").scrollIntoView({behavior:"smooth",block:"center"});
}
